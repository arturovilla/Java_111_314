import java.util.ArrayList;
import java.util.List;

public class GameMechanics
{
	public GameMechanics() {	}
	
	public static boolean BattleTester(ArrayList<?> list)
    {

        for (int i = 0; i < list.size(); i++)
        {
            int armour;
            try
            {
                Hero testHero = (Hero) list.get(i);
                armour = testHero.getArmour();
            }
            catch(Exception e)
            {
                System.out.println("Error list does not contain only heros!!!!!!!");
                return false;
            }
        }
        return true;


    }
	
}
