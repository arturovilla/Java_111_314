import java.util.ArrayList;
import java.util.Arrays;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Block testBlock = new Block("copper", new Location(0, 0, 0), 5);
		System.out.println(testBlock);
		
		// Character textCharacter = new Character
		// good, just checking, but since Character is abstract, can't create an instance
		
		Villain testVillain = new Villain("Creeper", new Location(0, 1, 0), false, "axe", 6);
		System.out.println(testVillain);

		
		Hero testHero = new Hero("Bowen", new Location(0, 0, 40), Arrays.asList("iron sword", "beef", "flare"), 5, 0) ;
		System.out.println(testHero);
		Hero testHero1 = new Hero("Bowen1", new Location(1, 0, 40), Arrays.asList("iron sword", "beef", "flare"), 5, 0) ;
		System.out.println(testHero1);
		Hero testHero2 = new Hero("Bowen2", new Location(2, 0, 40), Arrays.asList("iron sword", "beef", "flare"), 5, 0) ;
		System.out.println(testHero2);
		Hero testHero3 = new Hero("Bowen3", new Location(3, 0, 40), Arrays.asList("iron sword", "beef", "flare"), 5, 0) ;
		System.out.println(testHero3);

		GameMechanics gm = new GameMechanics();
		ArrayList<Character> BattleRoyale = new ArrayList<Character>();
		//BattleRoyale.add(testBlock); won't work!! (Thankfully)
		//BattleRoyale.add(testVillain);
		BattleRoyale.add(testHero);
		BattleRoyale.add(testHero1);
		BattleRoyale.add(testHero2);
		BattleRoyale.add(testHero3);
		BattleRoyale.add(testVillain);
		boolean ishero = gm.BattleTester(BattleRoyale);

		System.out.println("is the list all haeros??: " +  ishero);
		
		
		
	}

}
