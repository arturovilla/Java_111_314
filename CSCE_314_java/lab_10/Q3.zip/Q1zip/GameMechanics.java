import java.util.ArrayList;
import java.util.List;

public class GameMechanics
{
	public GameMechanics() {	}
	
	public static boolean BattleTester(ArrayList<?> list)
    {

        for (int i = 0; i < list.size(); i++)
        {
            int armour;
            try
            {
                Hero testHero = (Hero) list.get(i);
                armour = testHero.getArmour();
            }
            catch(Exception e)
            {
                System.out.println("Error list does not contain only heros!!!!!!!");
                return false;
            }
        }
        return true;


    }

    public static void basicWinChances(E<? extends Character> obj1, E<? extends Character> obj2, )
    {
        if(obj1 instanceof Hero && obj2 instanceof Hero)
        {
            System.out.println("HEROS DO NOT FIGHT HEROS \n");
            return;
        }
        if(obj1 instanceof Villain && obj2 instanceof Villain)
        {
            System.out.println("villains DO NOT FIGHT villains \n");
            return;
        }


        if(obj1 instanceof Hero)
        {
            Hero my1 = (Hero) obj1;
            Villain my2 = (Villain) obj2;

            if(my1.getHearts() > my2.getHearts())
            {
                double ratio = my2.getHearts() / my1.getHearts();
                System.out.println("HERO WINS BY A RATIO OF: " + ratio);
            }
        }
        if(obj1 instanceof Villain)
        {
            Villain my1 = (Villain)) obj1;
        }
        

    }
	
}
